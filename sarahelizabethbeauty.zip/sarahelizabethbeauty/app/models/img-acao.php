<?php

session_start();
require '../core/conn.php';

if(isset($_POST['img-criar'])){
    $apelido = mysqli_real_escape_string($conn, trim($_POST['f-apelido']));
    $tipo = mysqli_real_escape_string($conn, trim($_POST['f-tipo'])) ;
    $posicao = mysqli_real_escape_string($conn, trim($_POST['f-posicao'])) ;
    $endereco = mysqli_real_escape_string($conn, trim($_POST['f-endereco'])) ;

    $sql = "INSERT INTO images (apelido, tipo, posicao, endereco) VALUES ('$apelido', '$tipo', '$posicao', '$endereco')";

    mysqli_query($conn, $sql);
}

?>