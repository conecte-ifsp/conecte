<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
    <div class="container">

        <div class="header">
            <span>Gerenciamento de Portifólio</span>
            <a href="../views/img-gerenciar.php"><button>Voltar</button></a>
        </div>

        <div class="DivForm">
            <form action="img-acao.php" method="POST">
                <div>
                    <label for="f-apelido">Apelido</label>
                    <input id="f-apelido" type="text" required />
                </div>

                <div>
                    <label for="f-tipo">Tipo</label>
                    <input id="f-tipo" type="text" required />
                </div>

                <div>
                    <label for="f-posicao">Posição</label>
                    <input id="f-posicao" type="number" required />
                </div>

                <div>
                    <label for="f-endereco">Endereço</label>
                    <input id="f-endereco" type="text" required />
                </div>

                <div><button name="img-criar" type="submit">Salvar</button></div>

            </form>
        </div>
    </div>
    
</body>
</html>