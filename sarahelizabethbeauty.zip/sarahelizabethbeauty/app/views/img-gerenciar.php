<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
    <div class="container">

        <div class="header">
            <span>Gerenciamento de Portifólio</span>
            <a href="../models/img-adicionar.php"><button>Incluir</button></a>
        </div>

        <div class="DivTable">
            <table>
                <thead>
                    <tr>
                        <th>Apelido</th>
                        <th>Tipo</th>
                        <th>Posição</th>
                        <th>Endereço</th>
                        <th class="">Editar</th>
                        <th class="">Excluir</th>
                    </tr>
                </thead>
                <tbody> 
                    <tr>
                        <td>a</td>
                        <td>a</td>
                        <td>a</td>
                        <td>a</td>
                        <td><a href="img-editar.php"><button type="button">Edita</button></a></td>
                        <td><a href="img-excluir.php"><button type="button">Excloi</button></a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
</body>
</html>